/*
 * Name          : Mohamed Asad Bandarkar
 * Student Number: 4271451
 * CSC212 2023   : Term 4 Practical 1
 * File Name     : Algorithm2.java
 */
public class Algorithm2 {
    public static void findPairs(int[] array) {
        int i = 0;
        int j = array.length - 1;                     //i and j to traverse the array
        boolean found = false;
        while (i < j) {
            int sum = array[i] + array[j];            //calculating the sum of the elements at i and j in the array.
            if (sum == 0) {                           //if the sum equals 0
                System.out.println(array[i] + " and " + array[j] + " are in the array");
                found = true;
                i++;                                  //Incrementing i to move to the next element
                j--;                                  //decrementing j to move to the next element from back to front of the array
            } else if (sum > 0) {                     //if sum is greater than 0, move the j pointer to the left to reduce the sum
                j--;
            } else {                                  //if sum is less than 0, move the i pointer to the right to increase the sum
                i++;
            }
        }
        if (!found) {
            System.out.println("No pairs found");
        }
    }
}
