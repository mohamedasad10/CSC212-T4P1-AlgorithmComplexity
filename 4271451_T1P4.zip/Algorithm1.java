/*
 * Name          : Mohamed Asad Bandarkar
 * Student Number: 4271451
 * CSC212 2023   : Term 4 Practical 1
 * File Name     : Algorithm1.java
 */
public class Algorithm1 {
    public static void findPairs(int[] array) {
        boolean found = false;
        for (int i = 0; i < array.length; i++) {                   //iterate the array
            int x = array[i];
            for (int j = 0; j < array.length; j++) {
                if (array[j] == -x && j != i) {                   //for each element in the array,check if theres a negative version of that number in the array
                    System.out.println(x + " and " + -x + " are in the array");   //execute if there is a negative version of the number 
                    found = true;
                }
            }
        }
        if (!found) {                                             //execute if the x and -x pairs are not found
            System.out.println("No pairs found");
        }
    }
}
