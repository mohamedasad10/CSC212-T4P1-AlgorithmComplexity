/* Name          : Mohamed Asad Bandarkar
 * Student Number: 4271451
 * CSC212 2023   : Term 4 Practical 1
 * File Name     : Main.java
 * Citation for measuring time code: https://docs.oracle.com/javase/8/docs/api/java/lang/System.html
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            File file = new File("Input1.txt");                            //insert file into the File Object
            Scanner scanner = new Scanner(file);                                      // read through the file

            // Print the contents of the file to make sure all numbers in file are being considered
            System.out.println("File Contents:");
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
            scanner.close();

            scanner = new Scanner(file);                                              // Open the file for reading
            if (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] numberStrings = line.split(",");                       // transferring file items into an array to read
                int n = numberStrings.length;
                int[] array = new int[n];

                for (int i = 0; i < n; i++) {
                    array[i] = Integer.parseInt(numberStrings[i]);
                }

                //Citation from code below on measuring time: https://docs.oracle.com/javase/8/docs/api/java/lang/System.html 
                // Measure the runtime for Algorithm 1
                long startTimeAlgorithm1 = System.nanoTime();                         //citation for code above
                // Calling Algorithm 1
                System.out.println("\nAlgorithm 1 Results:");
                Algorithm1.findPairs(array);                                          // calling the findPairs method in Algorithm1.java
                
                long endTimeAlgorithm1 = System.nanoTime();                           //citation for code above
                long durationAlgorithm1 = endTimeAlgorithm1 - startTimeAlgorithm1;    //citation for code above

                // Measure the runtime for Algorithm 2
                long startTimeAlgorithm2 = System.nanoTime();
                // Calling Algorithm 2
                System.out.println("\nAlgorithm 2 Results:");
                Algorithm2.findPairs(array);                                           // calling the findPairs method in Algorithm2.java
                
                long endTimeAlgorithm2 = System.nanoTime();                            //citation for code above
                long durationAlgorithm2 = endTimeAlgorithm2 - startTimeAlgorithm2;     //citation for code above

                // Print runtimes in nanoseconds and seconds
                System.out.println("\nAlgorithm 1 Runtime (nanoseconds): " + durationAlgorithm1);
                System.out.println("Algorithm 1 Runtime (seconds): " + (durationAlgorithm1 / 1e9));   //convert the duration from nanoseconds to seconds.
                System.out.println("Algorithm 2 Runtime (nanoseconds): " + durationAlgorithm2);
                System.out.println("Algorithm 2 Runtime (seconds): " + (durationAlgorithm2 / 1e9));   //convert the duration from nanoseconds to seconds.
            } else {
                System.err.println("Invalid data format in the input file.");          //execute if file contents has a mismatch with formmatting
            }

            scanner.close();
        } catch (FileNotFoundException e) {                         // execute if the file is not found
            e.printStackTrace();
        }
    }
}